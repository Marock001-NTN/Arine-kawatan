(() => {
  const canvas = document.getElementById("gameCanvas");
  const ctx = canvas.getContext("2d");
  const scoreEl = document.getElementById("score");
  const bestEl = document.getElementById("best");
  const overlay = document.getElementById("overlay");
  const overlayTitle = document.getElementById("overlayTitle");
  const overlayDesc = document.getElementById("overlayDesc");
  const startBtn = document.getElementById("startBtn");

  const BEST_KEY = "myandroidgame_best_score";
  let width = window.innerWidth;
  let height = window.innerHeight;
  let running = false;
  let score = 0;
  let bestScore = loadBestScore();
  let lastTime = 0;
  let spawnTimer = 0;

  const player = {
    x: width / 2,
    y: height * 0.8,
    radius: 20,
    targetX: width / 2,
    targetY: height * 0.8
  };

  let items = [];
  let pointerActive = false;

  bestEl.textContent = String(bestScore);

  function loadBestScore() {
    try {
      return Number(localStorage.getItem(BEST_KEY)) || 0;
    } catch {
      return 0;
    }
  }

  function saveBestScore(value) {
    try {
      localStorage.setItem(BEST_KEY, String(value));
    } catch {
      // Ignore storage restrictions
    }
  }

  function resize() {
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    width = window.innerWidth;
    height = window.innerHeight;
    canvas.width = Math.floor(width * dpr);
    canvas.height = Math.floor(height * dpr);
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    player.x = Math.min(Math.max(player.x, player.radius), width - player.radius);
    player.y = Math.min(Math.max(player.y, player.radius), height - player.radius);
  }

  function resetGame() {
    score = 0;
    items = [];
    spawnTimer = 0;
    player.x = width / 2;
    player.y = height * 0.8;
    player.targetX = player.x;
    player.targetY = player.y;
    scoreEl.textContent = "0";
    running = true;
    overlay.classList.add("hidden");
    lastTime = performance.now();
  }

  function gameOver() {
    running = false;
    if (score > bestScore) {
      bestScore = score;
      bestEl.textContent = String(bestScore);
      saveBestScore(bestScore);
    }
    overlayTitle.textContent = "Kết thúc!";
    overlayDesc.textContent = `Bạn đạt ${score} điểm (Kỷ lục: ${bestScore}). Chạm để chơi lại!`;
    startBtn.textContent = "Chơi lại";
    overlay.classList.remove("hidden");
  }

  function spawnItem() {
    const isStar = Math.random() < 0.45;
    const radius = isStar ? 14 : 18 + Math.random() * 10;
    const speedBase = 170 + Math.min(score * 6, 260);
    items.push({
      type: isStar ? "star" : "hazard",
      x: radius + Math.random() * (width - radius * 2),
      y: -radius * 2,
      radius,
      speed: speedBase + Math.random() * 110
    });
  }

  function update(dt) {
    const followSpeed = 16;
    player.x += (player.targetX - player.x) * Math.min(1, followSpeed * dt);
    player.y += (player.targetY - player.y) * Math.min(1, followSpeed * dt);

    spawnTimer += dt;
    const spawnInterval = Math.max(0.28, 0.72 - score * 0.01);
    if (spawnTimer >= spawnInterval) {
      spawnTimer = 0;
      spawnItem();
    }

    for (let i = items.length - 1; i >= 0; i--) {
      const item = items[i];
      item.y += item.speed * dt;

      const dx = item.x - player.x;
      const dy = item.y - player.y;
      const dist = Math.hypot(dx, dy);

      if (dist < item.radius + player.radius) {
        if (item.type === "star") {
          score += 1;
          scoreEl.textContent = String(score);
          items.splice(i, 1);
          continue;
        } else {
          gameOver();
          return;
        }
      }

      if (item.y - item.radius > height + 40) {
        items.splice(i, 1);
      }
    }
  }

  function draw() {
    ctx.fillStyle = "#0b1020";
    ctx.fillRect(0, 0, width, height);

    for (const item of items) {
      ctx.beginPath();
      ctx.arc(item.x, item.y, item.radius, 0, Math.PI * 2);
      ctx.fillStyle = item.type === "star" ? "#facc15" : "#ef4444";
      ctx.fill();
    }

    ctx.beginPath();
    ctx.arc(player.x, player.y, player.radius, 0, Math.PI * 2);
    ctx.fillStyle = "#38bdf8";
    ctx.fill();
    ctx.lineWidth = 3;
    ctx.strokeStyle = "#e0f2fe";
    ctx.stroke();
  }

  function loop(now) {
    const dt = Math.min((now - lastTime) / 1000, 0.05);
    lastTime = now;
    if (running) {
      update(dt);
    }
    draw();
    requestAnimationFrame(loop);
  }

  function updateTarget(event) {
    player.targetX = Math.min(Math.max(event.clientX, player.radius), width - player.radius);
    player.targetY = Math.min(Math.max(event.clientY, player.radius), height - player.radius);
  }

  canvas.addEventListener("pointerdown", (e) => {
    pointerActive = true;
    updateTarget(e);
  });

  canvas.addEventListener("pointermove", (e) => {
    if (pointerActive) {
      updateTarget(e);
    }
  });

  window.addEventListener("pointerup", () => {
    pointerActive = false;
  });

  window.addEventListener("resize", resize);
  startBtn.addEventListener("click", resetGame);

  resize();
  requestAnimationFrame(loop);
})();
